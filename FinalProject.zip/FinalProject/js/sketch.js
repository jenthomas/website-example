var par;
var canvas;
var clearButton;
var input;
var inputButton;
var greeting;
var rSlider;
var rText;
var gSlider;
var gText;
var bSlider;
var bText;
var aSlider;
var aText;
var starSlider;
var starText;
var changeHeading;

/*function setup(){
    canvas=createCanvas(700,500);
    canvas.parent("Sketch");
    background(200,100,255);
    ellipse(100,100, 50,50);
    par=createP('Click me');
    par.position(200,100);
    //par.class('white');
    par.mousePressed(pClick);

    createSketchButtons();

    greeting=createElement('h2','Please enter your name!');
    input=createInput();
    inputButton=createButton('Submit');
    inputButton.mousePressed(greet);


   
}

function createSketchButtons(){
    clearButton= createButton('Clear');
    clearButton.mousePressed(clearCanvas);
    clearButton.parent("SketchButtons");

    rText= createP('Red Value');
    rText.parent("SketchButtons");
    rSlider= createSlider(0,255,100);
    rSlider.parent("SketchButtons");
    rSlider.input(colorChange);

    gText= createP('Green Value');
    gText.parent("SketchButtons");
    gSlider= createSlider(0,255,100);
    gSlider.parent("SketchButtons");
    gSlider.input(colorChange);

    bText= createP('Blue Value');
    bText.parent("SketchButtons");
    bSlider= createSlider(0,255,100);
    bSlider.parent("SketchButtons");
    bSlider.input(colorChange);

    aText= createP('Alpha Value');
    aText.parent("SketchButtons");
    aSlider= createSlider(0,100,100);
    aSlider.parent("SketchButtons");
    aSlider.input(colorChange);

    starText= createP('Star Points');
    starText.parent("SketchButtons");
    starSlider= createSlider(0,20,3);
    starSlider.parent("SketchButtons");

}

function colorChange(){
    rText.html('Red Value: ' + rSlider.value());
    fill(rSlider.value(),gSlider.value(),bSlider.value(), aSlider.value());
    rect(300,300,100,100);
}

function draw(){
   //background(255);
   star(200,100,50,starSlider.value());
}

function star(x, y, r, numPoints){
    var angle= TWO_PI /numPoints;
    beginShape();
    for(var theta=0; theta<TWO_PI; theta+= angle){
        var px= x+r*cos(theta);
        var py= y+r*sin(theta);
        vertex(px,py);

        px= x+r/2*cos(theta+angle/2);
        py= y+r/2*sin(theta+angle/2);
        vertex(px,py)
    }
       endShape(); 

}

function greet(){
    var name=input.value();
    greeting.html("Hello " +input.value()+"!");
    input.value('');
    for (var i=0; i<100; i++){
        fill(random(255), 0, 255, random(100));
        textSize(30+i);
        text(name, i*3, canvas.height/2+canvas.height/2*sin(i/10));
    }
    
}

function clearCanvas(){
    background(200,100,255);
    changeHeader.html("The heading has changed text.");
}

function pClick(){
    ellipse(150,150,50,50);
}*/
